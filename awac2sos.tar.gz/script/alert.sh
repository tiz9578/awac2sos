#! /bin/bash

# Cerca gli errori nel file di log

cat awac2.log | grep Exception > error.log

# Se il file con gli errori esiste ed è maggiore di zero invia una mail di alert

if test -s error.log

then
	echo "il file esiste ed è maggiore di zero"
	echo -e "subject:problemi SOS \nException Report nel log di awac2"|sendmail -f "david@xxxx.it" xxxxxx@gmail.com
else
	echo "il file non esiste o è zero"
fi

# Appendi il file awac2.log a awac2.sto - lo storico - 

cat awac2.log >> awac2.sto



#!/bin/bash

######################################################
######################################################
######################################################
#####################################################


cd /home/meteo/awac2/script/recupero/

wapfile=recupero.wap


#Ottieni le variabili

month=$(cat $wapfile | awk '{print $1}')
day=$(cat $wapfile | awk '{print $2}')
year=$(cat $wapfile | awk '{print $3}')
hour=$(cat $wapfile | awk '{print $4}')
min=$(cat $wapfile | awk '{print $5}')
sec=$(cat $wapfile | awk '{print $6}')
C1d=$(cat $wapfile | awk '{print $11}')
C1v=$(cat $wapfile | awk '{print $12}')

# Scrivi il log con l'ultima data inserita

#cd ../log

echo "$day-$month-$year $hour:$min:$sec" >> sensor1rec.log

# Spostati nella cartella dei file skel e dove produrre i file di inserimento
#cp ../../inser/InsertObservation2_C1d.xptf.xml .
#cp ../../inser/InsertObservation2_C1v.xptf.xml .

# Rimuovi l'ultime osservazioni inserite

rm InsertObservation2_C1d.xptf.xml
rm InsertObservation2_C1v.xptf.xml

# Preleva lo scheletro e inserisci le variabili.

# C10d
cat InsertObservation2_C1d.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C1d/$C1d/"  > InsertObservation2_C1d.xptf.xml

# C10v
cat InsertObservation2_C1v.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C1v/$C1v/"  > InsertObservation2_C1v.xptf.xml


# Fai Upload del file su David
curl -X POST -d @InsertObservation2_C1d.xptf.xml http://david.ve.ismar.cnr.it/52nSOSv3_WAR/sos
curl -X POST -d @InsertObservation2_C1v.xptf.xml http://david.ve.ismar.cnr.it/52nSOSv3_WAR/sos

#!/bin/bash
cd ../data

#Ottieni le variabili

wapfile=recupero.wap

month=$(cat $wapfile | awk '{print $1}')
#echo "mese = $month"
day=$(cat $wapfile | awk '{print $2}')
year=$(cat $wapfile | awk '{print $3}')
hour=$(cat $wapfile | awk '{print $4}')
min=$(cat $wapfile | awk '{print $5}')
sec=$(cat $wapfile | awk '{print $6}')
H0=$(cat $wapfile | awk '{print $8}')
H3=$(cat $wapfile | awk '{print $9}')
HX=$(cat $wapfile | awk '{print $11}')
DM=$(cat $wapfile | awk '{print $21}')
DP=$(cat $wapfile | awk '{print $19}')
SP=$(cat $wapfile | awk '{print $20}')
UI=$(cat $wapfile | awk '{print $22}')
T2=$(cat $wapfile | awk '{print $13}')
TP=$(cat $wapfile | awk '{print $14}')
T3=$(cat $wapfile | awk '{print $16}')
TZ=$(cat $wapfile | awk '{print $15}')
PM=$(cat $wapfile | awk '{print $23}')
MS=$(cat $wapfile | awk '{print $24}')

# Scrivi il log con l'ultima data inserita

#cd ../log

# echo "$day-$month-$year $hour:$min:$sec" >> lastobservation.log

# Spostati nella cartella dei file skel e dove produrre i file di inserimento
cd ../inser

# Qui potresti metter un rm *.xml

rm *.xml

# Preleva lo scheletro e inserisci le variabili.

# UI
cat InsertObservation_UI.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/UI/$UI/"  > InsertObservation_UI.xptf.xml

# TZ
cat InsertObservation_TZ.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/TZ/$TZ/"  > InsertObservation_TZ.xptf.xml

# TP
cat InsertObservation_TP.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/TP/$TP/"  > InsertObservation_TP.xptf.xml

# T3
cat InsertObservation_T3.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/T3/$T3/"  > InsertObservation_T3.xptf.xml

# T2
cat InsertObservation_T2.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/T2/$T2/"  > InsertObservation_T2.xptf.xml

# SP
cat InsertObservation_SP.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/SP/$SP/"  > InsertObservation_SP.xptf.xml

# PM
cat InsertObservation_PM.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/PM/$PM/"  > InsertObservation_PM.xptf.xml

# MS
cat InsertObservation_MS.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/MS/$MS/"  > InsertObservation_MS.xptf.xml

# HX
cat InsertObservation_HX.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/HX/$HX/"  > InsertObservation_HX.xptf.xml

# H3
cat InsertObservation_H3.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/H3/$H3/"  > InsertObservation_H3.xptf.xml

# H0
cat InsertObservation_H0.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/H0/$H0/"  > InsertObservation_H0.xptf.xml

# DP
cat InsertObservation_DP.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/DP/$DP/"  > InsertObservation_DP.xptf.xml

# DM
cat InsertObservation_DM.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/DM/$DM/"  > InsertObservation_DM.xptf.xml

###################### Ora bisogna far l'upload sul server SOS

# Prendi i file xml, fai l'upload 

for F in $(ls | grep .xml)

do
 curl -X POST -d @$F http://david.ve.ismar.cnr.it/52nSOSv3_WAR/sos
done

##############################################################################


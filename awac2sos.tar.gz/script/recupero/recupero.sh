#!/bin/bash

#cat recupero.wap | while read line; 

 cat export.c15 | while read line; 

do 

	echo "${line}">recupero.wap;
#	./awac2sosrec.sh ; 
	./c15rec.sh;

done

#!/bin/bash

######################################################
######################################################
######################################################
#####################################################


cd /home/meteo/awac2/data

wapfile=single.c03


#Ottieni le variabili

month=$(cat $wapfile | awk '{print $1}')
day=$(cat $wapfile | awk '{print $2}')
year=$(cat $wapfile | awk '{print $3}')
hour=$(cat $wapfile | awk '{print $4}')
min=$(cat $wapfile | awk '{print $5}')
sec=$(cat $wapfile | awk '{print $6}')
C3d=$(cat $wapfile | awk '{print $11}')
C3v=$(cat $wapfile | awk '{print $12}')

# Scrivi il log con l'ultima data inserita

cd ../log

echo "$day-$month-$year $hour:$min:$sec $wapfile" >> lastobservationsensor.log

# Spostati nella cartella dei file skel e dove produrre i file di inserimento
cd ../inser

# Rimuovi l'ultime osservazioni inserite

rm InsertObservation2_C3d.xptf.xml
rm InsertObservation2_C3v.xptf.xml

# Preleva lo scheletro e inserisci le variabili.

# C2d
cat InsertObservation2_C3d.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C3d/$C3d/"  > InsertObservation2_C3d.xptf.xml

# C2v
cat InsertObservation2_C3v.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C3v/$C3v/"  > InsertObservation2_C3v.xptf.xml


# Fai Upload del file su David
curl -X POST -d @InsertObservation2_C3d.xptf.xml http://david.ve.ismar.cnr.it/52nSOSv3_WAR/sos
curl -X POST -d @InsertObservation2_C3v.xptf.xml http://david.ve.ismar.cnr.it/52nSOSv3_WAR/sos

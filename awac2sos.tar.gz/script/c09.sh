#!/bin/bash

######################################################
######################################################
######################################################
#####################################################


cd /home/meteo/awac2/data

wapfile=single.c09


#Ottieni le variabili

month=$(cat $wapfile | awk '{print $1}')
day=$(cat $wapfile | awk '{print $2}')
year=$(cat $wapfile | awk '{print $3}')
hour=$(cat $wapfile | awk '{print $4}')
min=$(cat $wapfile | awk '{print $5}')
sec=$(cat $wapfile | awk '{print $6}')
C9d=$(cat $wapfile | awk '{print $11}')
C9v=$(cat $wapfile | awk '{print $12}')

# Scrivi il log con l'ultima data inserita

cd ../log

echo "$day-$month-$year $hour:$min:$sec $wapfile" >> lastobservationsensor.log

# Spostati nella cartella dei file skel e dove produrre i file di inserimento
cd ../inser

# Rimuovi l'ultime osservazioni inserite

rm InsertObservation2_C9d.xptf.xml
rm InsertObservation2_C9v.xptf.xml

# Preleva lo scheletro e inserisci le variabili.

# C2d
cat InsertObservation2_C9d.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C9d/$C9d/"  > InsertObservation2_C9d.xptf.xml

# C2v
cat InsertObservation2_C9v.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C9v/$C9v/"  > InsertObservation2_C9v.xptf.xml


# Fai Upload del file su David
curl -m 30 -X POST -d @InsertObservation2_C9d.xptf.xml http://127.0.0.1/52nSOSv3_WAR/sos
curl -m 30 -X POST -d @InsertObservation2_C9v.xptf.xml http://127.0.0.1/52nSOSv3_WAR/sos
exit

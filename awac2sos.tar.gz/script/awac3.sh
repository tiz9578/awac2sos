#!/bin/bash


function ctrlwap {

cd /home/meteo/awac2/data/
md5sum single.wap >> /home/meteo/awac2/log/md5.lst
md5=$(md5sum single.wap | awk '{print $1}')
#echo $md5

if [ $(grep "$md5" /home/meteo/awac2/log/md5.lst | wc -l) -gt 1 ]; 
then
	echo "Il file single.wap è lo stesso di prima."

else
	#esegui lo script per creare le osservazioni 
	echo "Il  file è nuovo: eseguo awac2sos.sh."
	cd /home/meteo/awac2/script
	./awac2sos.sh


fi
}

function ctrlsen {

cd /home/meteo/awac2/data/

md5sum single.sen >> /home/meteo/awac2/log/md5bot.lst

md5sen=$(md5sum single.sen | awk '{print $1}')
#echo $md5sen

if [ $(grep "$md5sen" /home/meteo/awac2/log/md5bot.lst | wc -l) -gt 1 ]; 
then
        echo "Il file single.sen è lo stesso di prima"

else
        #esegui lo script per creare le osservazioni 
	echo "I  file è nuovo: eseguobootomtemp2.sos.sh."
        cd /home/meteo/awac2/script
        ./bottomtemp2sos.sh


fi
}

function ctrlc01 {

cd /home/meteo/awac2/data/
wapfile=single.c01
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
	echo "I  file è nuovo: eseguo c01.sh."
        cd /home/meteo/awac2/script
        ./c01.sh
fi
}

function ctrlc02 {

cd /home/meteo/awac2/data/
wapfile=single.c02
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c02.sh
fi
}

function ctrlc03 {

cd /home/meteo/awac2/data/
wapfile=single.c03
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c03.sh
fi
}

function ctrlc04 {

cd /home/meteo/awac2/data/
wapfile=single.c04
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c04.sh
fi
}

function ctrlc05 {

cd /home/meteo/awac2/data/
wapfile=single.c05
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c05.sh
fi
}

function ctrlc06 {

cd /home/meteo/awac2/data/
wapfile=single.c06
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c06.sh
fi
}


function ctrlc07 {

cd /home/meteo/awac2/data/
wapfile=single.c07
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c07.sh
fi
}

function ctrlc08 {

cd /home/meteo/awac2/data/
wapfile=single.c08
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c08.sh
fi
}

function ctrlc09 {

cd /home/meteo/awac2/data/
wapfile=single.c09
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c09.sh
fi
}

function ctrlc10 {

cd /home/meteo/awac2/data/
wapfile=single.c10
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c10.sh
fi
}

function ctrlc11 {

cd /home/meteo/awac2/data/
wapfile=single.c11
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c11.sh
fi
}

function ctrlc12 {

cd /home/meteo/awac2/data/
wapfile=single.c12
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c12.sh
fi
}

function ctrlc13 {

cd /home/meteo/awac2/data/
wapfile=single.c13
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c13.sh
fi
}

function ctrlc14 {

cd /home/meteo/awac2/data/
wapfile=single.c14
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c14.sh
fi
}

function ctrlc15 {

cd /home/meteo/awac2/data/
wapfile=single.c15
md5sum $wapfile >> /home/meteo/awac2/log/md5sensors.lst
md5c=$(md5sum $wapfile | awk '{print $1}')
#echo $md5c
if [ $(grep "$md5c" /home/meteo/awac2/log/md5sensors.lst | wc -l) -gt 1 ];
then
        echo "Il file è lo stesso di prima"
else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./c15.sh
fi
}


function alert {
# Cerca gli errori nel file di log

cd  /home/meteo/awac2/log/

cat awac2.log | grep Exception > error.log

# Se il file con gli errori esiste ed è maggiore di zero invia una mail di alert

if test -s error.log

then
        echo "il file error.log esiste ed è maggiore di zero-controlla ci sono problemi"
   ####     echo -e "subject:problemi SOS \nException Report nel log di awac2"|sendmail -f "david@xxxx.it" xxxx@gmail.com
else
        echo "il file error.log non esiste o è zero: tutto bene"
fi

# Appendi il file awac2.log a awac2.sto - lo storico - 

cat awac2.log >> awac2.sto

}

ctrlwap
ctrlsen
ctrlc01
ctrlc02
ctrlc03
ctrlc04
ctrlc05
ctrlc06
ctrlc07
ctrlc08
ctrlc09
ctrlc10
ctrlc11
ctrlc12
ctrlc13
ctrlc14
ctrlc15
alert

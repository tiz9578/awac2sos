/usr/bin/rsync -avz -e ssh --delete meteo@ipaddress:/home/meteo/ascii/ 
/home/meteo/awac2/data/

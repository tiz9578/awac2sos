#!/bin/bash
cd /home/meteo/awac2/data/
md5sum single.wap >> /home/meteo/awac2/log/md5.lst

md5=$(md5sum single.wap | awk '{print $1}')
echo $md5

if [ $(grep "$md5" /home/meteo/awac2/log/md5.lst | wc -l) -gt 1 ]; 
then
	echo "Il file è lo stesso di prima...esco:"
	exit
     
else
	#esegui lo script per creare le osservazioni 
	cd /home/meteo/awac2/script
	./awac2sos.sh


fi



#!/bin/bash


function ctrlwap {

cd /home/meteo/awac2/data/
md5sum single.wap >> /home/meteo/awac2/log/md5.lst
md5=$(md5sum single.wap | awk '{print $1}')
echo $md5

if [ $(grep "$md5" /home/meteo/awac2/log/md5.lst | wc -l) -gt 1 ]; 
then
	echo "Il file single.wap è lo stesso di prima."

else
	#esegui lo script per creare le osservazioni 
	cd /home/meteo/awac2/script
	./awac2sos.sh


fi
}

function ctrlsen {

cd /home/meteo/awac2/data/

md5sum single.sen >> /home/meteo/awac2/log/md5.lst

md5sen=$(md5sum single.sen | awk '{print $1}')
echo $md5sen

if [ $(grep "$md5sen" /home/meteo/awac2/log/md5.lst | wc -l) -gt 1 ]; 
then
        echo "Il file single.sen è lo stesso di prima"

else
        #esegui lo script per creare le osservazioni 
        cd /home/meteo/awac2/script
        ./bottomtemp2sos.sh


fi
}

ctrlwap
ctrlsen

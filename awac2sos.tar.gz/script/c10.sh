#!/bin/bash

######################################################
######################################################
######################################################
#####################################################


cd /home/meteo/awac2/data

wapfile=single.c10

#Ottieni le variabili

month=$(cat $wapfile | awk '{print $1}')
day=$(cat $wapfile | awk '{print $2}')
year=$(cat $wapfile | awk '{print $3}')
hour=$(cat $wapfile | awk '{print $4}')
min=$(cat $wapfile | awk '{print $5}')
sec=$(cat $wapfile | awk '{print $6}')
C10d=$(cat $wapfile | awk '{print $11}')
C10v=$(cat $wapfile | awk '{print $12}')

# Scrivi il log con l'ultima data inserita

cd ../log

echo "$day-$month-$year $hour:$min:$sec $wapfile" >> lastobservationsensor.log

# Spostati nella cartella dei file skel e dove produrre i file di inserimento
cd ../inser

# Rimuovi l'ultime osservazioni inserite

rm InsertObservation2_C10d.xptf.xml
rm InsertObservation2_C10v.xptf.xml

# Preleva lo scheletro e inserisci le variabili.

# C2d
cat InsertObservation2_C10d.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C10d/$C10d/"  > InsertObservation2_C10d.xptf.xml

# C2v
cat InsertObservation2_C10v.xptf.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/C10v/$C10v/"  > InsertObservation2_C10v.xptf.xml


# Fai Upload del file su David
curl -m 30 -X POST -d @InsertObservation2_C10d.xptf.xml http://127.0.0.1/52nSOSv3_WAR/sos
curl -m 30 -X POST -d @InsertObservation2_C10v.xptf.xml http://127.0.0.1/52nSOSv3_WAR/sos
exit

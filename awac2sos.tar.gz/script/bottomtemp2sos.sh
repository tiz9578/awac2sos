#!/bin/bash
cd ../data

#Ottieni le variabili

wapfile=single.sen

month=$(cat $wapfile | awk '{print $1}')
#echo "mese = $month"
day=$(cat $wapfile | awk '{print $2}')
year=$(cat $wapfile | awk '{print $3}')
hour=$(cat $wapfile | awk '{print $4}')
min=$(cat $wapfile | awk '{print $5}')
sec=$(cat $wapfile | awk '{print $6}')
TE=$(cat $wapfile | awk '{print $15}')

# Scrivi il log con l'ultima data inserita

cd ../log

echo "$day-$month-$year $hour:$min:$sec" >> lastobservation.sen.log

# Spostati nella cartella dei file skel e dove produrre i file di inserimento
cd ../inser/sen

# Qui potresti metter un rm *.xml

rm te.js

# Preleva lo scheletro e inserisci le variabili.

# TE
UUID1=$(uuidgen | awk '{print $1}')
cat te.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID1/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/TTE/$TE/"  > te.js





######### UPLOAD#####################

###### configuration
LOGIN_URL=http://xxxxx/account/login/
BASE_URL=http://xxxxx/
USER='xxxxx'
PASSWORD='xxxx'


COOKIES=cookies.txt
CURL_BIN="curl -s -c $COOKIES -b $COOKIES -e $BASE_URL"

echo -n "Authentication - get csrftoken ... \n"
$CURL_BIN $BASE_URL > /dev/null
DJANGO_TOKEN="csrfmiddlewaretoken=$(grep csrftoken $COOKIES | sed 's/^.*csrftoken\s*//')"

echo -n "Login ... \n"
$CURL_BIN \
    -d "$DJANGO_TOKEN&username=$USER&password=$PASSWORD" \
    -X POST $LOGIN_URL

echo -n "Post JSONFILE ... \n"
$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @te.js ${BASE_URL}observations/sos/json


##############################################################################

exit

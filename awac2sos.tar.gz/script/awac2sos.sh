#!/bin/bash
cd /home/meteo/awac2/data

#Ottieni le variabili

wapfile=single.wap

status=$(cat $wapfile | awk '{print $7}')

echo $status


if [ "$status" == "0" ]; then

echo "status xe zero" > /dev/null
else


month=$(cat $wapfile | awk '{print $1}')
#echo "mese = $month"
day=$(cat $wapfile | awk '{print $2}')
year=$(cat $wapfile | awk '{print $3}')
hour=$(cat $wapfile | awk '{print $4}')
min=$(cat $wapfile | awk '{print $5}')
sec=$(cat $wapfile | awk '{print $6}')
H0=$(cat $wapfile | awk '{print $8}')
H3=$(cat $wapfile | awk '{print $9}')
HX=$(cat $wapfile | awk '{print $11}')
DM=$(cat $wapfile | awk '{print $21}')
DDP=$(cat $wapfile | awk '{print $19}')
SP=$(cat $wapfile | awk '{print $20}')
UIW=$(cat $wapfile | awk '{print $22}')
T2=$(cat $wapfile | awk '{print $13}')
TP=$(cat $wapfile | awk '{print $14}')
T3=$(cat $wapfile | awk '{print $16}')
TZ=$(cat $wapfile | awk '{print $15}')
PM=$(cat $wapfile | awk '{print $23}')
MS=$(cat $wapfile | awk '{print $24}')

# Scrivi il log con l'ultima data inserita

cd /home/meteo/awac2/log

echo "$day-$month-$year $hour:$min:$sec" >> lastobservation.log

# Spostati nella cartella dei file skel e dove produrre i file di inserimento
cd /home/meteo/awac2/inser

# Qui potresti metter un rm *.xml

rm t2.js h3.js t3.js dp.js tz.js hx.js dm.js sp.js tp.js pm.js ms.js h0.js

# Preleva lo scheletro e inserisci le variabili.

# UIW
UUID1=$(uuidgen | awk '{print $1}')
cat ui.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID1/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/UIW/$UIW/"  > ui.js

# TZ
UUID2=$(uuidgen | awk '{print $1}')
cat tz.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID2/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/TZ/$TZ/"  > tz.js

# TP
UUID3=$(uuidgen | awk '{print $1}')
cat tp.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID3/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/TP/$TP/"  > tp.js

# T3
UUID4=$(uuidgen | awk '{print $1}')
cat t3.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID4/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/T3/$T3/"  > t3.js

# T2
UUID5=$(uuidgen | awk '{print $1}')
cat t2.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID5/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/T2/$T2/"  > t2.js

# SP
UUID6=$(uuidgen | awk '{print $1}')
cat sp.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID6/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/SSP/$SP/"  > sp.js

# PM
UUID7=$(uuidgen | awk '{print $1}')
cat pm.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID7/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/PM/$PM/"  > pm.js

# MS
UUID8=$(uuidgen | awk '{print $1}')
cat ms.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID8/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/MS/$MS/"  > ms.js

# HX
UUID9=$(uuidgen | awk '{print $1}')
cat hx.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID9/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/HX/$HX/"  > hx.js

# H3
UUID10=$(uuidgen | awk '{print $1}')
cat h3.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID10/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/H3/$H3/"  > h3.js

# H0
UUID11=$(uuidgen | awk '{print $1}')
cat h0.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID11/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/H0/$H0/"  > h0.js

# DP
UUID12=$(uuidgen | awk '{print $1}')
cat dp.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID12/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/DDP/$DDP/"  > dp.js

# DM
UUID13=$(uuidgen | awk '{print $1}')
cat dm.skel | sed -e "s/MONTH/$month/" \
					| sed -e "s/UUID/$UUID13/" \
					| sed -e "s/DAY/$day/" \
					| sed -e "s/YEAR/$year/" \
					| sed -e "s/HOUR/$hour/" \
					| sed -e "s/MIN/$min/" \
					| sed -e "s/SEC/$sec/" \
					| sed -e "s/DM/$DM/"  > dm.js



######### UPLOAD#####################

###### configuration
LOGIN_URL=http://xxxxx/account/login/
BASE_URL=http://xxxxx/
USER='xxxxx'
PASSWORD='xxxx'


COOKIES=cookies.txt
CURL_BIN="curl -s -c $COOKIES -b $COOKIES -e $BASE_URL"

echo -n "Authentication - get csrftoken ... \n"
$CURL_BIN $BASE_URL > /dev/null
DJANGO_TOKEN="csrfmiddlewaretoken=$(grep csrftoken $COOKIES | sed 's/^.*csrftoken\s*//')"

echo -n "Login ... \n"
$CURL_BIN \
    -d "$DJANGO_TOKEN&username=$USER&password=$PASSWORD" \
    -X POST $LOGIN_URL

echo -n "Post JSONFILE ... \n"
$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @ui.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @tz.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @tp.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @t3.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @t2.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @sp.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @pm.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @ms.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @hx.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @h3.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @h0.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @dp.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @dm.js ${BASE_URL}observations/sos/json

fi


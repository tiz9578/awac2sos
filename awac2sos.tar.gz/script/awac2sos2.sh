#!/bin/bash
cd /home/meteo/awac2/data

#Ottieni le variabili

wapfile=testsingle.wap



status=$(cat $wapfile | awk '{print $7}')

echo $status


if [ "$status" == "0" ]; then

echo "status xe zero"
else
echo "status non xe zero"
fi




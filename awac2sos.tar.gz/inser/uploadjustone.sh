##### configuration
LOGIN_URL=http://vesk.ve.ismar.cnr.it/account/login/
BASE_URL=http://vesk.ve.ismar.cnr.it/
USER='starterkit'
PASSWORD='sk2014'


COOKIES=cookies.txt
CURL_BIN="curl -s -c $COOKIES -b $COOKIES -e $BASE_URL"

echo -n "Authentication - get csrftoken ... \n"
$CURL_BIN $BASE_URL > /dev/null
DJANGO_TOKEN="csrfmiddlewaretoken=$(grep csrftoken $COOKIES | sed 's/^.*csrftoken\s*//')"

echo -n "Login ... \n"
$CURL_BIN \
    -d "$DJANGO_TOKEN&username=$USER&password=$PASSWORD" \
    -X POST $LOGIN_URL

echo -n "Post JSONFILE ... \n"
$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @dp.js ${BASE_URL}observations/sos/json


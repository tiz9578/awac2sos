{
    "request": "InsertObservation",
    "service": "SOS",
    "version": "2.0.0",
    "offering": "offering:http://sp7.irea.cnr.it/sensors/vesk.ve.ismar.cnr.it/procedure/NortekAs/AWAC/noSerialNumberDeclared/20141217115413720_11525/observations",
    "observation": {
        "identifier": {
            "value": "239c7e5e-bf7e-45ac-865c-a7dfe8c90024",
            "codespace": ""
        },
        "type": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement",
        "featureOfInterest": {
            "identifier": {
                "value": "http://sp7.irea.cnr.it/sensors/vesk.ve.ismar.cnr.it/foi/SSF/SP/EPSG:4326/45.3138/12.5088",
                "codespace": ""
            },
            "name": [
                {
                    "value": "PTF - Piattaforma Acqua Alta",
                    "codespace": ""
                }
            ],
            "sampledFeature": ["http://www.marineregions.org/rest/getGazetteerRecordByMRGID.json/3314/"],
            "geometry": {
                "type": "Point",
                "coordinates": [
                    45.3138,
                    12.5088
                ],
                "crs": {
                    "type": "name",
                    "properties": {
                        "name": "EPSG:4326"
                    }
                }
            }
        },

        
	"procedure": "http://sp7.irea.cnr.it/sensors/vesk.ve.ismar.cnr.it/procedure/NortekAs/AWAC/noSerialNumberDeclared/20141217115413720_11525",
	"observedProperty": "http://vocab.nerc.ac.uk/collection/P02/current/TEMP/",
	"phenomenonTime": "2016-07-10T11:00:00+00:00",
        "resultTime": "2016-07-10T11:00:00+00:00",
        "result": {
            "uom": "degC",
            "value": 22.77
        }
    }
}
